import logo from './logo.svg';
import './App.css';
import  Getuser  from './Components/Getuser';

function App() {
  return (
    <div className="App">
      <Getuser/>
    </div>
  );
}

export default App;
