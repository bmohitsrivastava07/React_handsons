import React from 'react';
function CurrencyConverter()
{
    function evaluate()
    {
        var amt=0;
        <div>
            {document.getElementById("currency").value==="Euro"? amt=document.getElementById("amount").value*80:null}
            {document.getElementById("currency").value==="Dollar"? amt=document.getElementById("amount").value*60:null}
            {document.getElementById("currency").value==="Dinar"? amt=document.getElementById("amount").value*200:null}
        </div>
        
        alert("Converting the euro amount is "+amt);
    }

    return (<div>
        <h1 style={{color:"green"}}>Currency Converter!!!</h1>
        <table>
            <tr>
                <td>Amount</td>
                <td>
                    <input type="number" id="amount"></input>
                </td>
            </tr>
            
            <tr>
                <td>Currency</td>
                <td>
                    <input type="text" id="currency"></input>
                </td>
            </tr>
            <tr>
                <td></td>
                <td>
                    <button onClick={evaluate}>Submit</button>
                </td>
            </tr>
        </table>
    </div>)
}
export default CurrencyConverter;