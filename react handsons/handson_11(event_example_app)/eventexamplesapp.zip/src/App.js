import logo from './logo.svg';
import './App.css';
import Card from './Card';
import CurrencyConverter from './CurrencyConverter';

function App() {
  return (
    <div>
      <Card/>
      <CurrencyConverter/>
    </div>
  );
}

export default App;
