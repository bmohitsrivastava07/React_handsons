import React, { useState } from "react";
class Posts extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            posts: [],
            hasError: false,
            errorInfo: ''
        };
    }
    loadposts = async () => {
        const response = await fetch('https://jsonplaceholder.typicode.com/posts').then(res => res.json())
        return response;
    }

    async componentDidMount() {
        let Response = await this.loadposts();
        this.setState({
            posts: Response,
        });
    }
    render() {
        if(this.state.hasError){
            return <p>An error Occured!</p>
        }
        return (
            <div>

                {this.state.posts.map((post) => (
                    <div>
                        <h1>{post.title}</h1>
                        <p>{post.body}</p>
                    </div>
                ))}
            </div >

        )
    }
    componentDidCatch(error, info) {
        this.setState({ hasError: true, info: info});
        alert(error);
        alert(info)
    }
}

export default Posts;