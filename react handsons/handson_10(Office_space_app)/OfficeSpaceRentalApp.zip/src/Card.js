import './index.css';
import React from 'react';
function Card(props){
    const itemName=props.item.map((item)=>
    <div className="container">{item.rent<60000?
        <div>
            <img src={item.source} width="25%" height="25%" alt="Office Space"/>
            <h1>Name: {item.name}</h1>
            <h3 className='red'> Rent: Rs. {item.rent}</h3>
            <h3>Address: {item.address}</h3></div>:<div>
            <img src={item.source} width="25%" height="25%" alt="Office Space"/>
            <h1>Name: {item.name}</h1>
            <h3 className='green'> Rent: Rs. {item.rent}</h3>
            <h3>Address: {item.address}</h3></div>}
        </div>
    );
    return(
        <div>{itemName}</div>
    );
}

export default Card;