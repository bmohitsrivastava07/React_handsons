import logo from './logo.svg';
import './App.css';
import Card from './Card';
import House from './House';

function App() {
  return (
    <div>
      <h1 className='container'>Office Space, at Affordable Range</h1>
      <Card item={House}/>
    </div>
  );
}

export default App;
