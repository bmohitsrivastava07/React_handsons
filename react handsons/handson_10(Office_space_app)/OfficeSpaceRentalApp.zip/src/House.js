import OfficeSpace from'./OfficeSpace.jpg';
const House=[
    {
        source:OfficeSpace,
        name:"DBS",
        rent:50000,
        address:"Chennai"
    },
    {
        source:OfficeSpace,
        name:"QBS",
        rent:60000,
        address:"Banglore"
    },
    {
        source:OfficeSpace,
        name:"BETA",
        rent:10000,
        address:"Bhopal"
    },
    {
        source:OfficeSpace,
        name:"ALPHA",
        rent:9000,
        address:"Delhi"
    },
    {
        source:OfficeSpace,
        name:"GAMMA",
        rent:80000,
        address:"Jalandhar"
    }
]

export default House;