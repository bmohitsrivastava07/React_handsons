import { useParams } from "react-router-dom";
import trainersMock from "./TrainersMock";

function TrainerDetails(){
    const params=useParams();
    const trainer=trainersMock.find((t) => t.trainerId=== params.trainerId);
    return(
        <div style={{
            border:'3px solid black',
            margin:'6px',
            padding:'10px',
            width:300,
        }}>
            <h1>Trainer Details</h1>
            <h3>{trainer.name}</h3>
            <p>
                {trainer.email}
                <br/>
                <br/>
                {trainer.phone}
                <br/>
                <br/>
                {trainer.skills.map((skill)=>{
                    return(
                    <li>{skill}</li>
                    )
                })}
            </p>
        </div>
    )
}

export default TrainerDetails;