import { NavLink } from "react-router-dom";
const MainHeader=()=>{
return(
<>
<h1>My Academy Trainer App</h1>
      <p><NavLink to="/Home">Home</NavLink><span>|</span> <NavLink to="/trainers">Show Trainers</NavLink></p>
</>
);

}
export default MainHeader;