import trainer from './trainer';
const TrainersMock=[
   new trainer('t-syed8', 'Syed Khaleelullah','khaleelullah@cognizant.com','97676516962','.NET',['C#','SQL Server','React','.NET Core']),
   new trainer('t-jojo','Jojo Jose','jojo@cognizant.com','9897199231','Java',['Java','JSP','Angular','Spring']),
   new trainer('t-elisa','Elisa Jones','elisa@cognizant.com','9871212235','Python',['Python','Django','Angular'])
]
export default TrainersMock;