import MainHeader from "./MainHeader";

export const Home=()=>{
   return (
    <div>
        <MainHeader/>
        <h1>Welcome to My Academy trainers page</h1>
    </div>
   );
}

export default Home;