import MainHeader from "./MainHeader";
// import trainer from './trainer';
// import TrainersMock from "./TrainersMock";
export const TrainerList = (props) =>{
    return(
        <div>
               <MainHeader/>
            <h1>Trainers List</h1>
             <ul>
                <li><a href="/trainers/t-syed8">{props.trainer[0].name}</a></li>
                <li><a href="/trainers/t-jojo">{props.trainer[1].name}</a></li>
                <li><a href="/trainers/t-elisa">{props.trainer[2].name}</a></li>
            </ul>   
        </div>
    )
}
export default TrainerList;