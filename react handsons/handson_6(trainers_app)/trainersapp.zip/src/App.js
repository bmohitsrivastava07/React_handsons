import './App.css';
import React from 'react';
import { Routes, Route, N} from 'react-router-dom';
import Home from './Home';
import TrainerList from './TrainerList';
import TrainerDetails from './TrainerDetails';
import TrainersMock from './TrainersMock';
import MainHeader from './MainHeader';

function App() {
  return (
    <>
      <Routes>
		      <Route exact path="/" element={<MainHeader/>}/>
				<Route path="/Home" element={<Home/>}/>
        <Route path="/trainers" element={<TrainerList trainer={TrainersMock}/>}/>
          <Route path='/trainers/:trainerId' element={<TrainerDetails/>}/>
  </Routes>

    </>
  );
}

export default App;
