import React from 'react';
function ScoreLessThan70(props)
{
    const listItems=props.item.map((item)=>
    <div>{item.Score<=70 ?<li>Mr. {item.playername}<span> {item.Score}</span></li> :null}
        
    </div>
  );
  return (
    <div >
    <h1>List Of Players having Scores Less than 70</h1>
    
    {listItems}</div>
 );
}
export default ScoreLessThan70;