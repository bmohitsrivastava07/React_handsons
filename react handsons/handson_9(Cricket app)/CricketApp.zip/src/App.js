import logo from './logo.svg';
import './App.css';

function App(props) {
  const listItems=props.item.map((item)=>
  <div>
  
        <li>MR.{item.playername}<span> {item.Score}</span></li>
      </div>
);
return (
  <div >
  <h1>List Of Players</h1>
  {listItems}</div>
);
}

export default App;
