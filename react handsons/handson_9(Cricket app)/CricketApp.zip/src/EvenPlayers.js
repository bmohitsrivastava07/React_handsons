import React from 'react';
function EvenPlayers()
{
    return (<div>
        <h1>Even Players</h1>
        <li>Second : Dhoni2</li>
        <li>Fourth : Rohit4</li>
        <li>Sixth : Raina6</li>
    </div>)
}
export default EvenPlayers;