import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import Players from './Players';

ReactDOM.render(<Players />,document.getElementById('root'));
