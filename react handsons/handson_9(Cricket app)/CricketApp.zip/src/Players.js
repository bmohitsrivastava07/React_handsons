import React from 'react';
import App from './App';
import EvenPlayers from './EvenPlayers';
import ScoreLessThan70  from './ScoreLessThan70';
import OddPlayers from  './OddPlayers';
import IndianPlayers from './IndianPlayers';
function Players(){
const List=[
    {playername:" Jack",Score:50},
    {playername:" Michael",Score:70},
    {playername:" John",Score:40},
    {playername:" Ann",Score:61},
    {playername:" Elizabeth",Score:61},
    {playername:" Sachin",Score:95},
    {playername:" Dhoni",Score:100},
    {playername:" Virat",Score:84},
    {playername:" jadeja",Score:64},
    {playername:" Raina",Score:75},
    {playername:" Rohit",Score:80}
]

    return (
        <div>
          <App item={List}/>
          <ScoreLessThan70 item={List}/>
          <OddPlayers/>
          <EvenPlayers/>
          <IndianPlayers />
        </div>
    )

}

export default Players;