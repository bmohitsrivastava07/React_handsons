import React from 'react';
function OddPlayers()
{
    return (<div>
        <h1>Odd Players</h1>
        <li>First : Sachin1</li>
        <li>Third : Virat3</li>
        <li>Fifth : Yuvaraj5</li>
    </div>)
}
export default OddPlayers;